# FOCI TRACE v2 — Tender Workflow

FOCI TRACE v2 is a Java 21 browser application designed around the actual FOCI Group tender workflow:

**Tender ZIP → document register → BOQ → suppliers → calls/emails → quotations/OEM evidence → technical review → readiness → working BOQ export**

## Start in GitHub Codespaces

```bash
chmod +x build.sh run.sh
./build.sh
./run.sh
```

Open port **8080**. The included `.devcontainer/devcontainer.json` asks Codespaces to forward/open port 8080 automatically when the repository structure is preserved.

Seed login:

- Username: `admin`
- Password: `ChangeMe!2026`

The first login requires a password change.

## What v2 automates now

- Upload one Eskom/tender ZIP.
- Safely extract and index normal and nested ZIP files (up to two nested levels).
- Classify documents by filename into BOQ/Pricing, Technical, Addendum/Clarification, Quality, SDL&I, Contract, Returnables, Tender/ITT and General.
- Detect likely BOQ files in the tender pack.
- Automatically import BOQ rows from **.xlsx** or **.csv** when common columns are detected.
- Track suppliers, OEMs, distributors and their contact details.
- Record calls, emails, no-answer, awaiting-quote, quoted, declined and follow-up outcomes.
- Capture supplier quotations, prices, lead times and supporting evidence.
- Select the chosen quotation for the working BOQ.
- Track datasheet, COC/test certificate and OEM/distributor evidence.
- Record technical review and compliance status.
- Calculate per-line readiness and tender readiness percentage.
- Generate a supplier RFQ email draft from a BOQ line.
- Export a working BOQ CSV with selected supplier, quote, unit price, line total and readiness.
- Audit key user actions.
- Role-aware users: ADMIN, PROCUREMENT and ENGINEERING.

## Important limitations

FOCI TRACE v2 does **not** claim that filename classification proves compliance. It does not invent supplier prices, OEM evidence or technical compliance.

The automatic BOQ importer currently supports `.xlsx` and `.csv`. Legacy binary `.xls` files should be saved as `.xlsx` before importing.

PDF content is currently registered/indexed by filename but is not semantically read inside the Java application. A future AI-assisted tender-analysis module can add document-content analysis, mandatory-returnable extraction and supplier web research.

Supplier web sourcing and automatic outbound email are not enabled in this build because those functions require external services/connectors and account permissions.

## Data

Application data is stored under `data/`. Tender pack extracts are stored under `data/tenders/`. Do not commit live tender data or supplier quotations to a public repository.

## Security

For real deployment, use HTTPS and set:

```bash
FOCI_SECURE_COOKIE=true
```

Do not expose a live instance publicly while using the seed credentials.
