package za.co.focigroup.focitrace;

import com.sun.net.httpserver.HttpExchange;
import java.io.*;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class Web {
    private Web(){}
    public static Map<String,String> form(HttpExchange ex)throws IOException{return parseQuery(new String(ex.getRequestBody().readAllBytes(),StandardCharsets.UTF_8));}
    public static Map<String,String> query(HttpExchange ex){return parseQuery(ex.getRequestURI().getRawQuery());}
    private static Map<String,String> parseQuery(String raw){Map<String,String>out=new LinkedHashMap<>();if(raw==null||raw.isBlank())return out;for(String pair:raw.split("&")){String[]kv=pair.split("=",2);String k=URLDecoder.decode(kv[0],StandardCharsets.UTF_8);String v=kv.length>1?URLDecoder.decode(kv[1],StandardCharsets.UTF_8):"";out.put(k,v);}return out;}
    public static void html(HttpExchange ex,int status,String html)throws IOException{byte[]b=html.getBytes(StandardCharsets.UTF_8);ex.getResponseHeaders().set("Content-Type","text/html; charset=utf-8");securityHeaders(ex);ex.sendResponseHeaders(status,b.length);try(OutputStream os=ex.getResponseBody()){os.write(b);}}
    public static void text(HttpExchange ex,int status,String contentType,String text)throws IOException{byte[]b=text.getBytes(StandardCharsets.UTF_8);ex.getResponseHeaders().set("Content-Type",contentType+"; charset=utf-8");securityHeaders(ex);ex.sendResponseHeaders(status,b.length);try(OutputStream os=ex.getResponseBody()){os.write(b);}}
    public static void redirect(HttpExchange ex,String loc)throws IOException{ex.getResponseHeaders().set("Location",loc);securityHeaders(ex);ex.sendResponseHeaders(303,-1);ex.close();}
    public static void securityHeaders(HttpExchange ex){ex.getResponseHeaders().set("X-Content-Type-Options","nosniff");ex.getResponseHeaders().set("X-Frame-Options","DENY");ex.getResponseHeaders().set("Referrer-Policy","same-origin");ex.getResponseHeaders().set("Permissions-Policy","camera=(), microphone=(), geolocation=()");ex.getResponseHeaders().set("Content-Security-Policy","default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'");ex.getResponseHeaders().set("Cache-Control","no-store");}
    public static String e(Object v){if(v==null)return"";return v.toString().replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
    public static String p(Map<String,String>m,String k){return Optional.ofNullable(m.get(k)).orElse("").trim();}
    public static boolean bool(Map<String,String>m,String k){String v=p(m,k);return"on".equalsIgnoreCase(v)||"true".equalsIgnoreCase(v)||"yes".equalsIgnoreCase(v);}
    public static String enc(String s){return URLEncoder.encode(s==null?"":s,StandardCharsets.UTF_8);}
    public static String csv(String s){s=s==null?"":s;return "\""+s.replace("\"","\"\"")+"\"";}
}
