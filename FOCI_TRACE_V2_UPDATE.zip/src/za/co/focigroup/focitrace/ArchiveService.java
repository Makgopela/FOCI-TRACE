package za.co.focigroup.focitrace;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import static za.co.focigroup.focitrace.Models.*;

public final class ArchiveService {
    private static final int MAX_FILES=800;
    private static final long MAX_UNCOMPRESSED=500L*1024*1024;
    private ArchiveService(){}

    public record Result(List<TenderDocument> documents,List<Path> boqCandidates,long totalBytes){}

    public static Result extract(byte[]zipBytes,Path tenderRoot,String tenderId,Store store)throws IOException{
        Files.createDirectories(tenderRoot);List<TenderDocument>docs=new ArrayList<>();List<Path>boq=new ArrayList<>();Counter c=new Counter();
        extractLevel(zipBytes,tenderRoot,"",tenderId,store,docs,boq,c,0);return new Result(docs,boq,c.bytes);
    }

    private static void extractLevel(byte[]zipBytes,Path root,String prefix,String tenderId,Store store,List<TenderDocument>docs,List<Path>boq,Counter c,int depth)throws IOException{
        if(depth>2)return;
        try(ZipInputStream zin=new ZipInputStream(new ByteArrayInputStream(zipBytes))){ZipEntry e;while((e=zin.getNextEntry())!=null){
            if(e.isDirectory())continue;if(++c.files>MAX_FILES)throw new IOException("Tender archive contains too many files");
            String raw=(prefix+e.getName()).replace('\\','/');String clean=safeRelative(raw);if(clean.isBlank())continue;
            ByteArrayOutputStream b=new ByteArrayOutputStream();byte[]buf=new byte[8192];int n;while((n=zin.read(buf))>0){b.write(buf,0,n);c.bytes+=n;if(c.bytes>MAX_UNCOMPRESSED)throw new IOException("Tender archive expands beyond 500 MB");}
            byte[]data=b.toByteArray();Path out=root.resolve(clean).normalize();if(!out.startsWith(root))throw new IOException("Unsafe ZIP path");Files.createDirectories(out.getParent());Files.write(out,data,StandardOpenOption.CREATE,StandardOpenOption.TRUNCATE_EXISTING);
            String cat=category(clean);docs.add(new TenderDocument(store.nextDocumentId(),tenderId,Path.of(clean).getFileName().toString(),cat,data.length,clean,Store.now()));
            String lower=clean.toLowerCase(Locale.ROOT);if("BOQ / Pricing".equals(cat)&&(lower.endsWith(".xlsx")||lower.endsWith(".csv")))boq.add(out);
            if(lower.endsWith(".zip")&&depth<2){String folder=clean.substring(0,clean.length()-4)+"_unzipped/";extractLevel(data,root,folder,tenderId,store,docs,boq,c,depth+1);}
        }}catch(ZipException ze){throw new IOException("The uploaded file is not a valid ZIP archive",ze);}
    }

    public static String category(String filename){String n=filename.toLowerCase(Locale.ROOT);
        if(any(n,"boq","bill of quant","price schedule","pricing schedule","unpriced","priced boq"))return"BOQ / Pricing";
        if(any(n,"addendum","addenda","clarification"))return"Addendum / Clarification";
        if(any(n,"technical","specification","datasheet","schedule a","schedule b","drawing","dsg-"))return"Technical";
        if(any(n,"quality","iso","qm-","quality requirement"))return"Quality";
        if(any(n,"sdl&i","sdli","supplier development","localisation","localization"))return"SDL&I";
        if(any(n,"nec","contract data","conditions of contract","sc3","ecc"))return"Contract";
        if(any(n,"returnable","declaration","deviation","offer and acceptance","tenderer"))return"Returnables";
        if(any(n,"itt","invitation to tender","request for quotation","rfq","tender"))return"Tender / ITT";
        return"General";}
    private static boolean any(String n,String...terms){for(String t:terms)if(n.contains(t))return true;return false;}
    private static String safeRelative(String s){String[]parts=s.split("/");List<String>ok=new ArrayList<>();for(String p:parts){if(p.isBlank()||p.equals(".")||p.equals(".."))continue;ok.add(p.replaceAll("[\\x00-\\x1F]","_"));}return String.join("/",ok);}
    private static final class Counter{int files;long bytes;}
}
