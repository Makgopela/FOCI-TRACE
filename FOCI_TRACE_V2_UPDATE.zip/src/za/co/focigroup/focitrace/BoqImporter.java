package za.co.focigroup.focitrace;

import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipFile;
import static za.co.focigroup.focitrace.Models.*;

public final class BoqImporter {
    private BoqImporter(){}
    public record ImportResult(List<Requirement> requirements,String message,int headerRow){}

    public static ImportResult parse(Path file,String tenderId)throws Exception{
        String n=file.getFileName().toString().toLowerCase(Locale.ROOT);
        List<List<String>> rows;
        if(n.endsWith(".xlsx"))rows=readXlsx(file);
        else if(n.endsWith(".csv"))rows=readCsv(file);
        else return new ImportResult(List.of(),"Unsupported BOQ format. Use .xlsx or .csv.",-1);
        if(rows.isEmpty())return new ImportResult(List.of(),"No rows found in BOQ.",-1);
        Header h=findHeader(rows);if(h==null)return new ImportResult(List.of(),"Could not identify BOQ columns automatically. Expected headings such as Material/SAP, Description and Qty/Quantity.",-1);
        List<Requirement> out=new ArrayList<>();
        for(int i=h.row+1;i<rows.size();i++){
            List<String>r=rows.get(i);String desc=get(r,h.desc);String qtyRaw=get(r,h.qty);String material=h.material>=0?get(r,h.material):"";
            if(desc.isBlank()&&qtyRaw.isBlank()&&material.isBlank())continue;if(desc.isBlank())continue;
            BigDecimal qty=parseDecimal(qtyRaw);if(qty==null)continue;
            String unit=h.unit>=0?get(r,h.unit):"EA";String spec=h.spec>=0?get(r,h.spec):"";String docs=h.docs>=0?get(r,h.docs):"";
            if(material.isBlank())material="ITEM-"+(i+1);
            out.add(new Requirement(null,tenderId,material,desc,qty,unit.isBlank()?"EA":unit,spec,docs));
        }
        return new ImportResult(out,"Detected header row "+(h.row+1)+" and "+out.size()+" BOQ line(s).",h.row);
    }

    private record Header(int row,int material,int desc,int qty,int unit,int spec,int docs){}
    private static Header findHeader(List<List<String>>rows){
        int max=Math.min(rows.size(),25);for(int r=0;r<max;r++){List<String>row=rows.get(r);int m=-1,d=-1,q=-1,u=-1,s=-1,docs=-1;
            for(int c=0;c<row.size();c++){String x=norm(row.get(c));
                if(m<0&&matches(x,"material","material no","material number","sap","sap no","sap number","item no","item number","stock code","code"))m=c;
                if(d<0&&matches(x,"description","material description","item description","product description","scope description"))d=c;
                if(q<0&&matches(x,"qty","quantity","estimated quantity","total quantity"))q=c;
                if(u<0&&matches(x,"unit","uom","unit of measure","measure"))u=c;
                if(s<0&&(x.contains("spec")||x.contains("drawing")||x.contains("part no")||x.contains("part number")||x.contains("technical ref")))s=c;
                if(docs<0&&(x.contains("required document")||x.contains("evidence")||x.contains("documentation")))docs=c;
            }
            if(d>=0&&q>=0)return new Header(r,m,d,q,u,s,docs);
        }return null;
    }
    private static boolean matches(String x,String...vals){for(String v:vals)if(x.equals(v))return true;return false;}
    private static String norm(String s){return s==null?"":s.toLowerCase(Locale.ROOT).replace('\n',' ').replaceAll("\\s+"," ").trim();}
    private static String get(List<String>r,int i){return i>=0&&i<r.size()?r.get(i).trim():"";}
    private static BigDecimal parseDecimal(String s){if(s==null||s.isBlank())return null;String x=s.replace(",","").replaceAll("[^0-9.\\-]","");try{return x.isBlank()?null:new BigDecimal(x);}catch(Exception e){return null;}}

    private static List<List<String>> readCsv(Path file)throws IOException{List<List<String>>rows=new ArrayList<>();for(String line:Files.readAllLines(file,StandardCharsets.UTF_8))rows.add(parseCsvLine(line));return rows;}
    private static List<String> parseCsvLine(String line){List<String>out=new ArrayList<>();StringBuilder b=new StringBuilder();boolean q=false;for(int i=0;i<line.length();i++){char c=line.charAt(i);if(c=='"'){if(q&&i+1<line.length()&&line.charAt(i+1)=='"'){b.append('"');i++;}else q=!q;}else if(c==','&&!q){out.add(b.toString());b.setLength(0);}else b.append(c);}out.add(b.toString());return out;}

    private static List<List<String>> readXlsx(Path file)throws Exception{
        try(ZipFile zip=new ZipFile(file.toFile())){
            List<String>shared=readShared(zip);java.util.zip.ZipEntry sheet=zip.getEntry("xl/worksheets/sheet1.xml");
            if(sheet==null){sheet=zip.stream().filter(e->e.getName().startsWith("xl/worksheets/sheet")&&e.getName().endsWith(".xml")).findFirst().orElse(null);}if(sheet==null)return List.of();
            Document doc=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(zip.getInputStream(sheet));NodeList rowNodes=doc.getElementsByTagName("row");List<List<String>>rows=new ArrayList<>();
            for(int i=0;i<rowNodes.getLength();i++){Element row=(Element)rowNodes.item(i);NodeList cells=row.getElementsByTagName("c");Map<Integer,String>vals=new TreeMap<>();int max=-1;
                for(int j=0;j<cells.getLength();j++){Element c=(Element)cells.item(j);String ref=c.getAttribute("r");int col=colIndex(ref);String type=c.getAttribute("t");String value="";
                    if("inlineStr".equals(type)){NodeList ts=c.getElementsByTagName("t");if(ts.getLength()>0)value=ts.item(0).getTextContent();}
                    else{NodeList vs=c.getElementsByTagName("v");if(vs.getLength()>0){value=vs.item(0).getTextContent();if("s".equals(type)){try{int idx=Integer.parseInt(value);value=idx>=0&&idx<shared.size()?shared.get(idx):value;}catch(Exception ignored){}}}}
                    vals.put(col,value==null?"":value);max=Math.max(max,col);
                }
                List<String>list=new ArrayList<>();for(int c=0;c<=max;c++)list.add(vals.getOrDefault(c,""));rows.add(list);
            }return rows;
        }
    }
    private static List<String> readShared(ZipFile zip)throws Exception{java.util.zip.ZipEntry e=zip.getEntry("xl/sharedStrings.xml");if(e==null)return List.of();Document d=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(zip.getInputStream(e));NodeList sis=d.getElementsByTagName("si");List<String>out=new ArrayList<>();for(int i=0;i<sis.getLength();i++){Element si=(Element)sis.item(i);NodeList ts=si.getElementsByTagName("t");StringBuilder b=new StringBuilder();for(int j=0;j<ts.getLength();j++)b.append(ts.item(j).getTextContent());out.add(b.toString());}return out;}
    private static int colIndex(String ref){int n=0;for(int i=0;i<ref.length();i++){char c=ref.charAt(i);if(c>='A'&&c<='Z')n=n*26+(c-'A'+1);else if(c>='a'&&c<='z')n=n*26+(c-'a'+1);else break;}return Math.max(0,n-1);}
}
