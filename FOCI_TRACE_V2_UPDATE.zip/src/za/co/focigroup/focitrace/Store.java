package za.co.focigroup.focitrace;

import java.io.*;
import java.math.BigDecimal;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
import static za.co.focigroup.focitrace.Models.*;

public final class Store {
    private final Path file;
    private State state;
    private static final DateTimeFormatter TS=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public Store(Path dataDir)throws IOException{
        Files.createDirectories(dataDir); this.file=dataDir.resolve("state.bin"); this.state=load();
        if(state.users.isEmpty()) seed();
    }

    private State load(){
        if(!Files.exists(file))return new State();
        try(ObjectInputStream in=new ObjectInputStream(Files.newInputStream(file))){return (State)in.readObject();}
        catch(Exception e){throw new IllegalStateException("Could not read FOCI TRACE data store: "+e.getMessage(),e);}
    }
    private synchronized void save(){
        Path tmp=file.resolveSibling(file.getFileName()+".tmp");
        try(ObjectOutputStream out=new ObjectOutputStream(Files.newOutputStream(tmp,StandardOpenOption.CREATE,StandardOpenOption.TRUNCATE_EXISTING))){out.writeObject(state);out.flush();}
        catch(IOException e){throw new UncheckedIOException(e);}
        try{Files.move(tmp,file,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(IOException e){try{Files.move(tmp,file,StandardCopyOption.REPLACE_EXISTING);}catch(IOException x){throw new UncheckedIOException(x);}}
    }

    private void seed(){
        User admin=new User(); admin.username="admin";admin.displayName="FOCI Administrator";admin.role="ADMIN";Passwords.Hash h=Passwords.hash("ChangeMe!2026");admin.passwordHash=h.hashBase64();admin.salt=h.saltBase64();admin.iterations=h.iterations();state.users.add(admin);
        Tender t=new Tender(nextTenderId(),"E3509GXNOU","Koeberg procurement traceability starter set","Eskom","","","Active","Seed data",now(),"Starter records retained from the September FOCI TRACE prototype."); state.tenders.add(t);
        addReqNoSave(t.id(),"144746","CABLE ELECT:250 V;3;COPPER;2.5 MM2;PVC",new BigDecimal("4500"),"EA","-","Product datasheet; COC / test certificate");
        addReqNoSave(t.id(),"144751","WIRE ELECT:BUILDING;1.5 MM2;BLUE;CU;PVC",new BigDecimal("2300"),"EA","DSG-315-200","Product datasheet; COC / test certificate");
        addReqNoSave(t.id(),"144834","CABLE ELECT:1000;4;COPPER;1.5 MM2;4 CORE",new BigDecimal("300"),"EA","DSG-311-104","Product datasheet; COC / test certificate");
        addReqNoSave(t.id(),"502724","CABLE ASSY:0.36 IN;LG 20 FT",new BigDecimal("24"),"EA","DSG-312-201","OEM evidence; technical datasheet");
        addReqNoSave(t.id(),"717834","CARD, ELEC:MICROBOARD;PROGRAM STORAGE",new BigDecimal("3"),"EA","York/JCI 031-03601-002","OEM evidence; product datasheet");
        addReqNoSave(t.id(),"554089","PROCESSOR:ZONE;11-14 VDC",new BigDecimal("1"),"EA","Multivid H101429","COC; product datasheet");
        addReqNoSave(t.id(),"746993","PLUG:EST3 CENTRAL PROCESSOR;FR-4",new BigDecimal("6"),"EA","Edwards 3-CPU3","OEM evidence; product datasheet");
        addReqNoSave(t.id(),"746994","PLUG:EST3 POWER SUPPLY;FR-4",new BigDecimal("6"),"EA","Edwards 3-PPS/M","OEM evidence; product datasheet");
        state.suppliers.add(new Supplier(nextSupplierId(),"Springbok Electric","","","","","Electrical","Prospect","Starter supplier from prototype"));
        state.suppliers.add(new Supplier(nextSupplierId(),"ATC","","","","","Electrical","Prospect","Starter supplier from prototype"));
        state.suppliers.add(new Supplier(nextSupplierId(),"Westinghouse Electric Company / NAMCO","","","","","OEM","Prospect","Starter supplier from prototype"));
        state.suppliers.add(new Supplier(nextSupplierId(),"York / Johnson Controls (JCI)","","","","","OEM","Prospect","Starter supplier from prototype"));
        state.suppliers.add(new Supplier(nextSupplierId(),"Multivid","","","","","OEM","Prospect","Starter supplier from prototype"));
        state.suppliers.add(new Supplier(nextSupplierId(),"Edwards / UTC Fire & Security","","","","","OEM","Prospect","Starter supplier from prototype"));
        audit("system","SEED","SYSTEM","initial","Created starter tender, requirements and suppliers"); save();
    }
    private void addReqNoSave(String tenderId,String material,String desc,BigDecimal qty,String unit,String spec,String docs){state.requirements.add(new Requirement(nextReqId(),tenderId,material,desc,qty,unit,spec,docs));}

    public synchronized State snapshot(){return deepCopy(state);}
    private State deepCopy(State s){try{ByteArrayOutputStream b=new ByteArrayOutputStream();try(ObjectOutputStream o=new ObjectOutputStream(b)){o.writeObject(s);}try(ObjectInputStream i=new ObjectInputStream(new ByteArrayInputStream(b.toByteArray()))){return (State)i.readObject();}}catch(Exception e){throw new IllegalStateException(e);}}

    public synchronized User user(String username){return state.users.stream().filter(u->u.username.equalsIgnoreCase(username)&&u.active).findFirst().orElse(null);}
    public synchronized void changePassword(String username,String password){User u=user(username);if(u==null)throw new IllegalArgumentException("User not found");Passwords.Hash h=Passwords.hash(password);u.passwordHash=h.hashBase64();u.salt=h.saltBase64();u.iterations=h.iterations();u.mustChangePassword=false;save();}

    public synchronized Tender addTender(String no,String title,String customer,String closing,String contact,String sourceZip,String notes){Tender t=new Tender(nextTenderId(),no,title,customer,closing,contact,"Active",sourceZip,now(),notes);state.tenders.add(t);save();return t;}
    public synchronized void addDocuments(List<TenderDocument> docs){state.documents.addAll(docs);save();}
    public synchronized String nextDocumentId(){return String.format("DOC-%03d",state.docSeq++);}    
    public synchronized Requirement addRequirement(String tenderId,String material,String desc,BigDecimal qty,String unit,String spec,String docs){Requirement r=new Requirement(nextReqId(),tenderId,material,desc,qty,unit,spec,docs);state.requirements.add(r);save();return r;}
    public synchronized int addRequirements(List<Requirement> rows){for(Requirement r:rows){r.id=nextReqId();state.requirements.add(r);}save();return rows.size();}
    public synchronized Supplier addSupplier(String name,String contact,String email,String phone,String website,String category,String status,String notes){Supplier s=new Supplier(nextSupplierId(),name,contact,email,phone,website,category,status,notes);state.suppliers.add(s);save();return s;}
    public synchronized ContactLog addContact(String supplierId,String tenderId,String method,String outcome,String notes,String user){ContactLog c=new ContactLog(nextContactId(),supplierId,tenderId,method,outcome,now(),notes,user);state.contacts.add(c);Supplier s=findSupplier(supplierId);if(s!=null)s.status=outcome;save();return c;}
    public synchronized Quote addQuote(Quote q,boolean select){q.id=nextQuoteId();if(q.receivedDate==null||q.receivedDate.isBlank())q.receivedDate=now().substring(0,10);state.quotes.add(q);Requirement r=findRequirement(q.requirementId);if(r!=null&&select){r.selectedSupplierId=q.supplierId;r.selectedQuoteId=q.id;r.selectedUnitPrice=q.unitPrice;r.currency=q.currency;r.datasheetReceived=q.datasheet;r.cocTestReceived=q.cocTest;r.oemLetterReceived=q.oemLetter;}save();return q;}
    public synchronized void updateRequirement(String id,String supplierId,String quoteId,String spec,String docs,boolean datasheet,boolean coc,boolean oem,String techReview,String compliance,String notes){Requirement r=findRequirement(id);if(r==null)throw new IllegalArgumentException("Requirement not found");r.selectedSupplierId=nvl(supplierId);r.selectedQuoteId=nvl(quoteId);r.specRef=nvl(spec);r.requiredDocs=nvl(docs);r.datasheetReceived=datasheet;r.cocTestReceived=coc;r.oemLetterReceived=oem;r.technicalReview=nvl(techReview);r.compliance=nvl(compliance);r.notes=nvl(notes);if(!r.selectedQuoteId.isBlank()){Quote q=findQuote(r.selectedQuoteId);if(q!=null){r.selectedUnitPrice=q.unitPrice;r.currency=q.currency;}}save();}
    public synchronized User addUser(String username,String display,String role,String password){if(state.users.stream().anyMatch(u->u.username.equalsIgnoreCase(username)))throw new IllegalArgumentException("Username already exists");User u=new User();u.username=username.toLowerCase(Locale.ROOT);u.displayName=display;u.role=role;Passwords.Hash h=Passwords.hash(password);u.passwordHash=h.hashBase64();u.salt=h.saltBase64();u.iterations=h.iterations();state.users.add(u);save();return u;}
    public synchronized void audit(String user,String action,String entity,String entityId,String details){state.audits.add(new Audit(String.format("AUD-%05d",state.auditSeq++),now(),user,action,entity,entityId,details));if(state.audits.size()>1500)state.audits.remove(0);save();}

    public synchronized Tender findTender(String id){return state.tenders.stream().filter(x->x.id().equals(id)).findFirst().orElse(null);}
    public synchronized Requirement findRequirement(String id){return state.requirements.stream().filter(x->Objects.equals(x.id,id)).findFirst().orElse(null);}
    public synchronized Supplier findSupplier(String id){return state.suppliers.stream().filter(x->Objects.equals(x.id,id)).findFirst().orElse(null);}
    public synchronized Quote findQuote(String id){return state.quotes.stream().filter(x->Objects.equals(x.id,id)).findFirst().orElse(null);}

    public synchronized List<Tender> tenders(){return new ArrayList<>(state.tenders);}
    public synchronized List<TenderDocument> docs(String tenderId){return state.documents.stream().filter(d->tenderId==null||tenderId.isBlank()||d.tenderId().equals(tenderId)).toList();}
    public synchronized List<Requirement> requirements(String tenderId){return state.requirements.stream().filter(r->tenderId==null||tenderId.isBlank()||Objects.equals(r.tenderId,tenderId)).toList();}
    public synchronized List<Supplier> suppliers(){return new ArrayList<>(state.suppliers);}
    public synchronized List<ContactLog> contacts(){List<ContactLog>x=new ArrayList<>(state.contacts);Collections.reverse(x);return x;}
    public synchronized List<Quote> quotes(String tenderId){return state.quotes.stream().filter(q->tenderId==null||tenderId.isBlank()||Objects.equals(q.tenderId,tenderId)).toList();}
    public synchronized List<Audit> audits(){List<Audit>x=new ArrayList<>(state.audits);Collections.reverse(x);return x.stream().limit(400).toList();}
    public synchronized List<User> users(){return new ArrayList<>(state.users);}

    public synchronized String nextTenderId(){return String.format("TND-%03d",state.tenderSeq++);}    
    private String nextReqId(){return String.format("REQ-%04d",state.reqSeq++);}    
    private String nextSupplierId(){return String.format("SUP-%03d",state.supplierSeq++);}    
    private String nextContactId(){return String.format("CNT-%04d",state.contactSeq++);}    
    private String nextQuoteId(){return String.format("QUO-%04d",state.quoteSeq++);}    
    public static String now(){return LocalDateTime.now().format(TS);}    
    private static String nvl(String s){return s==null?"":s;}

    public static boolean requirementReady(Requirement r,List<Quote>quotes){
        boolean priced=r.selectedUnitPrice!=null || quotes.stream().anyMatch(q->Objects.equals(q.requirementId,r.id)&&q.unitPrice!=null);
        boolean docs=requiredEvidenceSatisfied(r);
        return priced&&docs&&"Reviewed".equalsIgnoreCase(r.technicalReview)&&"Compliant".equalsIgnoreCase(r.compliance);
    }
    public static boolean requiredEvidenceSatisfied(Requirement r){
        String d=(r.requiredDocs==null?"":r.requiredDocs).toLowerCase(Locale.ROOT);
        if(d.contains("datasheet")&&!r.datasheetReceived)return false;
        if((d.contains("coc")||d.contains("test certificate"))&&!r.cocTestReceived)return false;
        if(d.contains("oem")&&!r.oemLetterReceived)return false;
        return true;
    }
    public static String readinessStatus(Requirement r,List<Quote>qs){
        boolean priced=r.selectedUnitPrice!=null||qs.stream().anyMatch(q->Objects.equals(q.requirementId,r.id)&&q.unitPrice!=null);
        if(!priced)return"Awaiting Quote";
        if(!requiredEvidenceSatisfied(r))return"Missing Documents";
        if(!"Reviewed".equalsIgnoreCase(r.technicalReview))return"Technical Review";
        if(!"Compliant".equalsIgnoreCase(r.compliance))return"Compliance Review";
        return"Ready";
    }
}
