package za.co.focigroup.focitrace;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.*;

public final class Models {
    private Models() {}

    public static final class State implements Serializable {
        private static final long serialVersionUID = 1L;
        public int tenderSeq=1, docSeq=1, reqSeq=1, supplierSeq=1, contactSeq=1, quoteSeq=1, auditSeq=1;
        public final List<Tender> tenders = new ArrayList<>();
        public final List<TenderDocument> documents = new ArrayList<>();
        public final List<Requirement> requirements = new ArrayList<>();
        public final List<Supplier> suppliers = new ArrayList<>();
        public final List<ContactLog> contacts = new ArrayList<>();
        public final List<Quote> quotes = new ArrayList<>();
        public final List<Audit> audits = new ArrayList<>();
        public final List<User> users = new ArrayList<>();
    }

    public record Tender(String id, String tenderNo, String title, String customer, String closingDate,
                         String contactEmail, String status, String sourceZip, String importedAt,
                         String notes) implements Serializable {
        private static final long serialVersionUID = 1L;
    }

    public record TenderDocument(String id, String tenderId, String fileName, String category,
                                 long sizeBytes, String relativePath, String indexedAt) implements Serializable {
        private static final long serialVersionUID = 1L;
    }

    public static final class Requirement implements Serializable {
        private static final long serialVersionUID = 1L;
        public String id, tenderId, materialNo, description, unit, specRef, requiredDocs;
        public BigDecimal qty;
        public String selectedSupplierId, selectedQuoteId;
        public BigDecimal selectedUnitPrice;
        public String currency="ZAR";
        public boolean datasheetReceived, cocTestReceived, oemLetterReceived;
        public String technicalReview="Pending", compliance="Review Required", notes="";

        public Requirement() {}
        public Requirement(String id, String tenderId, String materialNo, String description, BigDecimal qty, String unit,
                           String specRef, String requiredDocs) {
            this.id=id; this.tenderId=tenderId; this.materialNo=materialNo; this.description=description; this.qty=qty;
            this.unit=unit; this.specRef=specRef; this.requiredDocs=requiredDocs;
        }
    }

    public static final class Supplier implements Serializable {
        private static final long serialVersionUID = 1L;
        public String id, name, contactPerson, email, phone, website, category, status, notes;
        public Supplier() {}
        public Supplier(String id,String name,String contactPerson,String email,String phone,String website,String category,String status,String notes){
            this.id=id;this.name=name;this.contactPerson=contactPerson;this.email=email;this.phone=phone;this.website=website;this.category=category;this.status=status;this.notes=notes;
        }
    }

    public record ContactLog(String id, String supplierId, String tenderId, String method, String outcome,
                             String contactedAt, String notes, String user) implements Serializable {
        private static final long serialVersionUID = 1L;
    }

    public static final class Quote implements Serializable {
        private static final long serialVersionUID = 1L;
        public String id, tenderId, supplierId, requirementId, quoteRef, currency, receivedDate, notes;
        public BigDecimal unitPrice;
        public Integer leadDays;
        public boolean datasheet, cocTest, oemLetter;
        public String status;
        public Quote() {}
    }

    public record Audit(String id, String at, String user, String action, String entity, String entityId,
                        String details) implements Serializable {
        private static final long serialVersionUID = 1L;
    }

    public static final class User implements Serializable {
        private static final long serialVersionUID = 1L;
        public String username, displayName, role, passwordHash, salt;
        public int iterations;
        public boolean mustChangePassword=true, active=true;
        public User() {}
    }
}
