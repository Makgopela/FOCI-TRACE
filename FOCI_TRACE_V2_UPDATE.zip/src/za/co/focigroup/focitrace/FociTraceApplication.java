package za.co.focigroup.focitrace;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.Executors;
import static za.co.focigroup.focitrace.Models.*;

public final class FociTraceApplication {
    private final Store store;
    private final SessionManager sessions;
    private final HttpServer server;
    private final Path dataDir;

    public FociTraceApplication(int port,Path dataDir,boolean secureCookie)throws Exception{
        this.dataDir=dataDir.toAbsolutePath().normalize();Files.createDirectories(this.dataDir);
        this.store=new Store(this.dataDir);this.sessions=new SessionManager(secureCookie);
        this.server=HttpServer.create(new InetSocketAddress("0.0.0.0",port),0);
        this.server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());routes();
    }

    private void routes(){
        ctx("/login",this::login);ctx("/logout",this::logout);ctx("/change-password",this::changePassword);
        ctx("/tenders/upload",this::uploadTender);ctx("/tenders/view",this::viewTender);ctx("/tenders",this::tenders);
        ctx("/boq/import",this::importBoq);ctx("/requirements/update",this::updateRequirement);ctx("/requirements/edit",this::editRequirement);ctx("/requirements",this::requirements);
        ctx("/suppliers/create",this::createSupplier);ctx("/suppliers",this::suppliers);
        ctx("/contacts/create",this::createContact);ctx("/contacts",this::contacts);
        ctx("/quotes/create",this::createQuote);ctx("/quotes",this::quotes);
        ctx("/email-draft",this::emailDraft);ctx("/readiness",this::readiness);ctx("/export/boq.csv",this::exportBoq);
        ctx("/audit",this::audit);ctx("/users/create",this::createUser);ctx("/users",this::users);ctx("/health",this::health);ctx("/",this::dashboard);
    }
    private void ctx(String path,Handler h){server.createContext(path,ex->{try{h.handle(ex);}catch(Stop stop){return;}catch(Exception e){e.printStackTrace();try{SessionManager.Session s=sessions.get(ex).orElse(null);Web.html(ex,500,Html.layout("Error",s,"<section class='panel'><h2>Something went wrong</h2><div class='error'>"+Web.e(e.getMessage())+"</div><p>No data was intentionally fabricated. Correct the input and try again.</p></section>",null));}catch(Exception ignored){}}});}
    public void start(){server.start();System.out.println("FOCI TRACE v2 running on http://localhost:"+server.getAddress().getPort());System.out.println("Seed login: admin / ChangeMe!2026 (password change required)");}

    private void login(HttpExchange ex)throws Exception{
        if(isGet(ex)){Web.html(ex,200,Html.login(null));return;}requirePost(ex);Map<String,String>f=Web.form(ex);String user=Web.p(f,"username").toLowerCase(Locale.ROOT),pass=Web.p(f,"password");User u=store.user(user);
        if(u==null||!Passwords.verify(pass,u.passwordHash,u.salt,u.iterations)){store.audit(user.isBlank()?"unknown":user,"LOGIN_FAILED","USER",user,"Invalid sign-in attempt");Web.html(ex,401,Html.login("Invalid username or password."));return;}
        SessionManager.Session s=sessions.create(u.username,u.displayName,u.role,u.mustChangePassword);sessions.attach(ex,s);store.audit(u.username,"LOGIN","USER",u.username,"Successful sign in");Web.redirect(ex,s.mustChangePassword()?"/change-password":"/");
    }
    private void logout(HttpExchange ex)throws Exception{sessions.get(ex).ifPresent(s->store.audit(s.username(),"LOGOUT","USER",s.username(),"Signed out"));sessions.destroy(ex);Web.redirect(ex,"/login");}
    private void changePassword(HttpExchange ex)throws Exception{SessionManager.Session s=auth(ex);if(s==null)return;if(isGet(ex)){Web.html(ex,200,Html.layout("Change password",s,Html.changePassword(s,null),null));return;}requirePost(ex);Map<String,String>f=Web.form(ex);csrf(s,Web.p(f,"csrf"));String p=Web.p(f,"password"),c=Web.p(f,"confirm");if(p.length()<12){Web.html(ex,400,Html.layout("Change password",s,Html.changePassword(s,"Password must be at least 12 characters."),null));return;}if(!p.equals(c)){Web.html(ex,400,Html.layout("Change password",s,Html.changePassword(s,"Passwords do not match."),null));return;}store.changePassword(s.username(),p);store.audit(s.username(),"PASSWORD_CHANGE","USER",s.username(),"Password updated");sessions.markPasswordChanged(s);Web.redirect(ex,"/?msg=Password+updated");}

    private void dashboard(HttpExchange ex)throws Exception{SessionManager.Session s=auth(ex);if(s==null)return;requireGet(ex);Web.html(ex,200,Html.layout("Dashboard",s,Html.dashboard(store),msg(ex)));}
    private void tenders(HttpExchange ex)throws Exception{SessionManager.Session s=auth(ex);if(s==null)return;requireGet(ex);Web.html(ex,200,Html.layout("Tender Intake",s,Html.tenders(store.tenders(),s),msg(ex)));}

    private void uploadTender(HttpExchange ex)throws Exception{
        SessionManager.Session s=authRole(ex,"ADMIN","PROCUREMENT");if(s==null)return;requirePost(ex);Map<String,Multipart.Part>p=Multipart.parse(ex,120*1024*1024);csrf(s,text(p,"csrf"));
        Multipart.Part zip=p.get("tender_zip");if(zip==null||zip.data().length==0)throw new IllegalArgumentException("Tender ZIP is required");String filename=safeFilename(zip.filename());if(!filename.toLowerCase(Locale.ROOT).endsWith(".zip"))throw new IllegalArgumentException("Upload the tender pack as a .zip file");
        Tender t=store.addTender(textReq(p,"tender_no"),textReq(p,"title"),defaultIfBlank(text(p,"customer"),"Eskom"),text(p,"closing_date"),text(p,"contact_email"),filename,text(p,"notes"));
        Path root=dataDir.resolve("tenders").resolve(t.id());Files.createDirectories(root);Files.write(root.resolve("ORIGINAL_"+filename),zip.data());
        ArchiveService.Result result=ArchiveService.extract(zip.data(),root.resolve("extracted"),t.id(),store);store.addDocuments(result.documents());
        int imported=0;String importNote="";BoqImporter.ImportResult best=null;Path bestPath=null;
        for(Path candidate:result.boqCandidates()){try{BoqImporter.ImportResult r=BoqImporter.parse(candidate,t.id());if(!r.requirements().isEmpty()&&(best==null||r.requirements().size()>best.requirements().size())){best=r;bestPath=candidate;}}catch(Exception ignored){}}
        if(best!=null){imported=store.addRequirements(best.requirements());importNote=" Auto-imported "+imported+" BOQ line(s) from "+bestPath.getFileName()+".";}
        store.audit(s.username(),"TENDER_UPLOAD","TENDER",t.id(),"Uploaded "+filename+"; indexed "+result.documents().size()+" file(s)."+importNote);
        Web.redirect(ex,"/tenders/view?id="+Web.enc(t.id())+"&msg="+Web.enc("Tender pack indexed: "+result.documents().size()+" files."+importNote));
    }

    private void viewTender(HttpExchange ex)throws Exception{SessionManager.Session s=auth(ex);if(s==null)return;requireGet(ex);String id=Web.p(Web.query(ex),"id");Tender t=store.findTender(id);if(t==null)throw new IllegalArgumentException("Tender not found");Web.html(ex,200,Html.layout("Tender "+t.tenderNo(),s,Html.tenderView(t,store.docs(id),store.requirements(id),s),msg(ex)));}

    private void importBoq(HttpExchange ex)throws Exception{
        SessionManager.Session s=authRole(ex,"ADMIN","PROCUREMENT");if(s==null)return;requirePost(ex);Map<String,Multipart.Part>p=Multipart.parse(ex,35*1024*1024);csrf(s,text(p,"csrf"));String tenderId=textReq(p,"tender_id");if(store.findTender(tenderId)==null)throw new IllegalArgumentException("Tender not found");Multipart.Part file=p.get("boq_file");if(file==null||file.data().length==0)throw new IllegalArgumentException("BOQ file is required");String fn=safeFilename(file.filename());String lower=fn.toLowerCase(Locale.ROOT);if(!(lower.endsWith(".xlsx")||lower.endsWith(".csv")))throw new IllegalArgumentException("Use an .xlsx or .csv BOQ. Legacy .xls is not yet supported by the automatic importer.");Path dir=dataDir.resolve("tenders").resolve(tenderId).resolve("manual-imports");Files.createDirectories(dir);Path target=dir.resolve(UUID.randomUUID()+"_"+fn);Files.write(target,file.data());BoqImporter.ImportResult r=BoqImporter.parse(target,tenderId);if(r.requirements().isEmpty())throw new IllegalArgumentException(r.message());int n=store.addRequirements(r.requirements());store.audit(s.username(),"BOQ_IMPORT","TENDER",tenderId,"Imported "+n+" item(s) from "+fn);Web.redirect(ex,"/requirements?tender="+Web.enc(tenderId)+"&msg="+Web.enc("Imported "+n+" BOQ line(s) from "+fn));
    }

    private void requirements(HttpExchange ex)throws Exception{SessionManager.Session s=auth(ex);if(s==null)return;requireGet(ex);String tender=Web.p(Web.query(ex),"tender");List<Requirement>rows=store.requirements(tender);Web.html(ex,200,Html.layout("BOQ / Requirements",s,Html.requirements(rows,store.tenders(),store.suppliers(),store.quotes(tender),tender,s),msg(ex)));}
    private void editRequirement(HttpExchange ex)throws Exception{SessionManager.Session s=auth(ex);if(s==null)return;requireGet(ex);Requirement r=store.findRequirement(Web.p(Web.query(ex),"id"));if(r==null)throw new IllegalArgumentException("Requirement not found");Web.html(ex,200,Html.layout("Review BOQ Item",s,Html.requirementEdit(r,store.suppliers(),store.quotes(r.tenderId),s),msg(ex)));}
    private void updateRequirement(HttpExchange ex)throws Exception{SessionManager.Session s=authRole(ex,"ADMIN","PROCUREMENT","ENGINEERING");if(s==null)return;requirePost(ex);Map<String,String>f=Web.form(ex);csrf(s,Web.p(f,"csrf"));String id=req(f,"id");store.updateRequirement(id,Web.p(f,"supplier_id"),Web.p(f,"quote_id"),Web.p(f,"spec_ref"),Web.p(f,"required_docs"),Web.bool(f,"datasheet"),Web.bool(f,"coc"),Web.bool(f,"oem"),Web.p(f,"technical_review"),Web.p(f,"compliance"),Web.p(f,"notes"));store.audit(s.username(),"REQUIREMENT_REVIEW","REQUIREMENT",id,"Updated supplier/evidence/technical compliance review");Web.redirect(ex,"/requirements/edit?id="+Web.enc(id)+"&msg=Review+saved");}

    private void suppliers(HttpExchange ex)throws Exception{SessionManager.Session s=auth(ex);if(s==null)return;requireGet(ex);Web.html(ex,200,Html.layout("Suppliers",s,Html.suppliers(store.suppliers(),store.tenders(),s),msg(ex)));}
    private void createSupplier(HttpExchange ex)throws Exception{SessionManager.Session s=authRole(ex,"ADMIN","PROCUREMENT");if(s==null)return;requirePost(ex);Map<String,String>f=Web.form(ex);csrf(s,Web.p(f,"csrf"));Supplier x=store.addSupplier(req(f,"name"),Web.p(f,"contact_person"),Web.p(f,"email"),Web.p(f,"phone"),Web.p(f,"website"),Web.p(f,"category"),"Prospect",Web.p(f,"notes"));store.audit(s.username(),"SUPPLIER_CREATE","SUPPLIER",x.id,"Added "+x.name);Web.redirect(ex,"/suppliers?msg=Supplier+added");}

    private void contacts(HttpExchange ex)throws Exception{SessionManager.Session s=auth(ex);if(s==null)return;requireGet(ex);String supplier=Web.p(Web.query(ex),"supplier");Web.html(ex,200,Html.layout("Supplier Contact Log",s,Html.contacts(store.contacts(),store.suppliers(),store.tenders(),supplier,s),msg(ex)));}
    private void createContact(HttpExchange ex)throws Exception{SessionManager.Session s=authRole(ex,"ADMIN","PROCUREMENT");if(s==null)return;requirePost(ex);Map<String,String>f=Web.form(ex);csrf(s,Web.p(f,"csrf"));String supplier=req(f,"supplier_id");if(store.findSupplier(supplier)==null)throw new IllegalArgumentException("Supplier not found");ContactLog c=store.addContact(supplier,Web.p(f,"tender_id"),Web.p(f,"method"),Web.p(f,"outcome"),Web.p(f,"notes"),s.username());store.audit(s.username(),"SUPPLIER_CONTACT","SUPPLIER",supplier,c.method()+" — "+c.outcome());Web.redirect(ex,"/contacts?supplier="+Web.enc(supplier)+"&msg=Contact+logged");}

    private void quotes(HttpExchange ex)throws Exception{SessionManager.Session s=auth(ex);if(s==null)return;requireGet(ex);Web.html(ex,200,Html.layout("Quotations",s,Html.quotes(store.quotes(""),store.tenders(),store.suppliers(),store.requirements(""),s),msg(ex)));}
    private void createQuote(HttpExchange ex)throws Exception{SessionManager.Session s=authRole(ex,"ADMIN","PROCUREMENT");if(s==null)return;requirePost(ex);Map<String,String>f=Web.form(ex);csrf(s,Web.p(f,"csrf"));String tender=req(f,"tender_id"),requirement=req(f,"requirement_id"),supplier=req(f,"supplier_id");Requirement r=store.findRequirement(requirement);if(r==null||!Objects.equals(r.tenderId,tender))throw new IllegalArgumentException("Selected BOQ item does not belong to the selected tender");if(store.findSupplier(supplier)==null)throw new IllegalArgumentException("Supplier not found");Quote q=new Quote();q.tenderId=tender;q.requirementId=requirement;q.supplierId=supplier;q.quoteRef=req(f,"quote_ref");q.unitPrice=decimal(req(f,"unit_price"));q.currency=defaultIfBlank(Web.p(f,"currency"),"ZAR");q.leadDays=integer(Web.p(f,"lead_days"));q.status=Web.p(f,"status");q.datasheet=Web.bool(f,"datasheet");q.cocTest=Web.bool(f,"coc");q.oemLetter=Web.bool(f,"oem");q.notes=Web.p(f,"notes");Quote saved=store.addQuote(q,Web.bool(f,"select_for_boq"));store.audit(s.username(),"QUOTE_CREATE","QUOTATION",saved.id,"Supplier "+supplier+" for "+requirement+"; unit price "+q.currency+" "+q.unitPrice);Web.redirect(ex,"/quotes?msg=Quotation+saved");}

    private void emailDraft(HttpExchange ex)throws Exception{SessionManager.Session s=auth(ex);if(s==null)return;requireGet(ex);Requirement r=store.findRequirement(Web.p(Web.query(ex),"requirement"));if(r==null)throw new IllegalArgumentException("Requirement not found");Tender t=store.findTender(r.tenderId);Supplier supplier=store.findSupplier(r.selectedSupplierId);Web.html(ex,200,Html.layout("RFQ Email Draft",s,Html.emailDraft(r,t,supplier),null));}
    private void readiness(HttpExchange ex)throws Exception{SessionManager.Session s=auth(ex);if(s==null)return;requireGet(ex);String tender=Web.p(Web.query(ex),"tender");Web.html(ex,200,Html.layout("Readiness",s,Html.readiness(store.tenders(),store.requirements(""),store.quotes(""),tender),msg(ex)));}
    private void exportBoq(HttpExchange ex)throws Exception{SessionManager.Session s=auth(ex);if(s==null)return;requireGet(ex);String tender=Web.p(Web.query(ex),"tender");Tender t=store.findTender(tender);if(t==null)throw new IllegalArgumentException("Tender not found");StringBuilder csv=new StringBuilder("Requirement ID,Material No,Description,Quantity,Unit,Spec Ref,Selected Supplier,Quote Ref,Unit Price,Currency,Line Total,Technical Review,Compliance,Readiness\n");List<Supplier>suppliers=store.suppliers();List<Quote>quotes=store.quotes(tender);for(Requirement r:store.requirements(tender)){Supplier sup=store.findSupplier(r.selectedSupplierId);Quote q=store.findQuote(r.selectedQuoteId);BigDecimal total=(r.qty!=null&&r.selectedUnitPrice!=null)?r.qty.multiply(r.selectedUnitPrice):null;csv.append(String.join(",",Web.csv(r.id),Web.csv(r.materialNo),Web.csv(r.description),Web.csv(r.qty==null?"":r.qty.toPlainString()),Web.csv(r.unit),Web.csv(r.specRef),Web.csv(sup==null?"":sup.name),Web.csv(q==null?"":q.quoteRef),Web.csv(r.selectedUnitPrice==null?"":r.selectedUnitPrice.toPlainString()),Web.csv(r.currency),Web.csv(total==null?"":total.toPlainString()),Web.csv(r.technicalReview),Web.csv(r.compliance),Web.csv(Store.readinessStatus(r,quotes)))).append('\n');}ex.getResponseHeaders().set("Content-Disposition","attachment; filename=\""+safeFilename(t.tenderNo())+"_working_BOQ.csv\"");Web.text(ex,200,"text/csv",csv.toString());}

    private void audit(HttpExchange ex)throws Exception{SessionManager.Session s=auth(ex);if(s==null)return;requireGet(ex);Web.html(ex,200,Html.layout("Audit Trail",s,Html.audit(store.audits()),msg(ex)));}
    private void users(HttpExchange ex)throws Exception{SessionManager.Session s=authRole(ex,"ADMIN");if(s==null)return;requireGet(ex);Web.html(ex,200,Html.layout("Users",s,Html.users(store.users(),s),msg(ex)));}
    private void createUser(HttpExchange ex)throws Exception{SessionManager.Session s=authRole(ex,"ADMIN");if(s==null)return;requirePost(ex);Map<String,String>f=Web.form(ex);csrf(s,Web.p(f,"csrf"));String pw=req(f,"password");if(pw.length()<12)throw new IllegalArgumentException("Temporary password must be at least 12 characters");User u=store.addUser(req(f,"username"),req(f,"display_name"),req(f,"role"),pw);store.audit(s.username(),"USER_CREATE","USER",u.username,"Role "+u.role);Web.redirect(ex,"/users?msg=User+created");}
    private void health(HttpExchange ex)throws Exception{Web.text(ex,200,"text/plain","FOCI TRACE v2 OK");}

    private SessionManager.Session auth(HttpExchange ex)throws IOException{Optional<SessionManager.Session>o=sessions.get(ex);if(o.isEmpty()){Web.redirect(ex,"/login");return null;}SessionManager.Session s=o.get();String path=ex.getRequestURI().getPath();if(s.mustChangePassword()&&!path.equals("/change-password")&&!path.equals("/logout")){Web.redirect(ex,"/change-password");return null;}return s;}
    private SessionManager.Session authRole(HttpExchange ex,String...roles)throws IOException{SessionManager.Session s=auth(ex);if(s==null)return null;if(!s.hasRole(roles)){Web.html(ex,403,Html.layout("Forbidden",s,"<section class='panel'><h2>403 Forbidden</h2><p>Your role does not have permission for this action.</p></section>",null));return null;}return s;}
    private void csrf(SessionManager.Session s,String token){if(!sessions.validCsrf(s,token))throw new SecurityException("Security token expired. Refresh the page and try again.");}
    private static void requireGet(HttpExchange ex)throws IOException{if(!isGet(ex)){Web.html(ex,405,"<h1>405 Method Not Allowed</h1>");throw new Stop();}}
    private static void requirePost(HttpExchange ex)throws IOException{if(!isPost(ex)){Web.html(ex,405,"<h1>405 Method Not Allowed</h1>");throw new Stop();}}
    private static boolean isGet(HttpExchange ex){return"GET".equalsIgnoreCase(ex.getRequestMethod());}private static boolean isPost(HttpExchange ex){return"POST".equalsIgnoreCase(ex.getRequestMethod());}
    private static String msg(HttpExchange ex){return Web.p(Web.query(ex),"msg");}
    private static String req(Map<String,String>m,String k){String v=Web.p(m,k);if(v.isBlank())throw new IllegalArgumentException(k+" is required");return v;}
    private static String text(Map<String,Multipart.Part>p,String k){Multipart.Part x=p.get(k);return x==null?"":x.text();}
    private static String textReq(Map<String,Multipart.Part>p,String k){String v=text(p,k);if(v.isBlank())throw new IllegalArgumentException(k+" is required");return v;}
    private static BigDecimal decimal(String s){try{return new BigDecimal(s.replace(",",""));}catch(Exception e){throw new IllegalArgumentException("Invalid price: "+s);}}
    private static Integer integer(String s){if(s==null||s.isBlank())return null;try{return Integer.valueOf(s);}catch(Exception e){throw new IllegalArgumentException("Invalid whole number: "+s);}}
    private static String defaultIfBlank(String s,String fallback){return s==null||s.isBlank()?fallback:s;}
    private static String safeFilename(String n){if(n==null||n.isBlank())return"file";return Path.of(n).getFileName().toString().replaceAll("[^A-Za-z0-9._-]","_");}
    private interface Handler{void handle(HttpExchange ex)throws Exception;}private static final class Stop extends RuntimeException{}

    public static void main(String[]args)throws Exception{int port=Integer.parseInt(System.getenv().getOrDefault("PORT","8080"));Path data=Path.of(System.getenv().getOrDefault("FOCI_DATA_DIR","data"));boolean secure=Boolean.parseBoolean(System.getenv().getOrDefault("FOCI_SECURE_COOKIE","false"));new FociTraceApplication(port,data,secure).start();}
}
