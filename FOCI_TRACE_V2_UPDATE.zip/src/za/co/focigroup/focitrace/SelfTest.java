package za.co.focigroup.focitrace;

import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import static za.co.focigroup.focitrace.Models.*;

public final class SelfTest {
    public static void main(String[]args)throws Exception{
        testCategory();testCsvImport();testReadiness();testArchive();System.out.println("FOCI TRACE v2 self-tests: 4/4 PASS");
    }
    private static void testCategory(){eq("BOQ / Pricing",ArchiveService.category("UNPRICED BOQ.xlsx"));eq("Addendum / Clarification",ArchiveService.category("Addendum 2.pdf"));eq("Technical",ArchiveService.category("technical schedule A.xlsx"));}
    private static void testCsvImport()throws Exception{Path p=Files.createTempFile("boq-test",".csv");Files.writeString(p,"SAP,Description,Quantity,UOM,Specification\n12345,Cable 6mm,5000,m,DSG-001\n",StandardCharsets.UTF_8);BoqImporter.ImportResult r=BoqImporter.parse(p,"TND-999");eq(1,r.requirements().size());eq("12345",r.requirements().get(0).materialNo);Files.deleteIfExists(p);}
    private static void testReadiness(){Requirement r=new Requirement("REQ-X","TND-X","1","Cable",new BigDecimal("10"),"m","DSG","Datasheet; COC; OEM evidence");r.selectedUnitPrice=new BigDecimal("2");r.datasheetReceived=true;r.cocTestReceived=true;r.oemLetterReceived=true;r.technicalReview="Reviewed";r.compliance="Compliant";if(!Store.requirementReady(r,List.of()))throw new AssertionError("readiness failed");}
    private static void testArchive()throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();try(ZipOutputStream z=new ZipOutputStream(b)){z.putNextEntry(new ZipEntry("docs/Addendum 1.pdf"));z.write("x".getBytes(StandardCharsets.UTF_8));z.closeEntry();}Path d=Files.createTempDirectory("zip-test");Store store=new Store(d.resolve("db"));ArchiveService.Result r=ArchiveService.extract(b.toByteArray(),d.resolve("out"),"TND-X",store);eq(1,r.documents().size());eq("Addendum / Clarification",r.documents().get(0).category());}
    private static void eq(Object e,Object a){if(!Objects.equals(e,a))throw new AssertionError("expected="+e+" actual="+a);}
}
